import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './src/screens/home';
import { AllThemeColors } from './src/utils/responsive';
import { StatusBar } from 'react-native';

const Stack = createNativeStackNavigator();

const MyStack = () => {
  return (
    <NavigationContainer>
      <StatusBar
        backgroundColor={AllThemeColors.themeColorPrimary}
        barStyle="light-content"
      />
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={Home}
          options={{
            title: 'Timer List',
            headerTitleAlign: 'center',
            headerBackTitle: '',
            headerTintColor: AllThemeColors.white,
            headerStyle: {
              backgroundColor: AllThemeColors.themeColorPrimary,
            },
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default MyStack;