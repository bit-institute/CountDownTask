import { Dimensions, Platform, PixelRatio } from 'react-native';

const { width, height } = Dimensions.get('window');
import themeJson from './theme.json'
import { EventRegister } from 'react-native-event-listeners';
import moment from 'moment';
import { scale, verticalScale, moderateScale, moderateVerticalScale } from 'react-native-size-matters';

const STANDARD_WIDTH = 375; const CURRENT_WIDTH = width;
const K = CURRENT_WIDTH / STANDARD_WIDTH;
const USE_FOR_BIGGER_SIZE = true;
export function dynamicSize(size) { return K * size || 0; }
export function getFontSize(size) {
    if (USE_FOR_BIGGER_SIZE || CURRENT_WIDTH < STANDARD_WIDTH) {
        const newSize = dynamicSize(size); return newSize;
    }
    return size;
}

export function s(size) { return scale(size) }
export function vs(size) { return verticalScale(size) }
export function ms(size) { return moderateScale(size) }
export function mvs(size) { return moderateVerticalScale(size) }


// export const scaleFont = size => size * PixelRatio.getFontScale();
export function showCustomAlert(msg, color) {
    EventRegister.emit('CustomEventForAlert', { msg: msg, color: color == 'fail' ? AllThemeColors.alertFailColor : color == 'success' ? AllThemeColors.alertSuccessColor : AllThemeColors.alertErrorColor })

}

export const allRex = {
    integerRex: /[^0-9]/g,
    decimalRex: /[^0-9.]/g,
    alphaNumericRex: /[^A-Za-z0-9-]/g,
    alphaRex: /[^A-Za-z]/g,
    nameRex: /[^A-Za-z0-9.'_’ ]/g,
    nameRexWithoutSpace: /[^A-Za-z0-9.'_’ ]/g,

}
// export const frequencyArr = [{ title: 'daily' }, { title: 'weekly' }, { title: 'monthly' }, { title: 'quarterly' }, { title: 'annual' }, { title: 'one-off' }]
export const AllThemeColors = themeJson.colors;
export const orange = themeJson.colors.themeColorPrimary;
export const AllThemeFonts = themeJson.fontSize;
export const large = height >= 812 ? true : false


export function fontFamily(param) {

    // <string>Raleway-Bold.ttf</string>
    // <string>Raleway-ExtraBold.ttf</string>
    // <string>Raleway-ExtraLight.ttf</string>
    // <string>Raleway-Heavy.ttf</string>
    // <string>Raleway-Light.ttf</string>
    // <string>Raleway-Medium.ttf</string>
    // <string>Raleway-Regular.ttf</string>
    // <string>Raleway-SemiBold.ttf</string>
    // <string>Raleway-Thin.ttf</string>

    // if (param == "Bold") {
    //     return "Raleway-Bold"
    // }
    // if (param == "Medium") {
    //     return "Raleway-Medium"
    // }
    // if (param == "Regular") {
    //     return "Raleway-Regular"
    // }
    // if (param == "SemiBold") {
    //     return "Raleway-SemiBold"
    // }
    // return "Raleway-Regular"
    if (param == "Bold") {
        return "OpenSans-Bold"
    }
    if (param == "Medium") {
        return "OpenSans-Medium"
    }
    if (param == "Regular") {
        return "OpenSans-Regular"
    }
    if (param == "SemiBold") {
        return "OpenSans-SemiBold"
    }
    return "OpenSans-Regular"
    // return null
}





