

let basePath = '../assets/images/'

export default Image = {
    Common: {
        background: require(basePath + "background.jpg"),
        tick: require(basePath + "tick.png"),
        cross: require(basePath + "cross.png"),
        backspace: require(basePath + "back.png"),
        // imagePlaceholder:require(basePath`common/placeHolder.png`),
        // logo: require('../assets/images/common/bell.png'),
    },
}