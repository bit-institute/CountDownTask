import moment from 'moment';
import React, { useEffect, useState } from 'react';
import { FlatList, Keyboard, KeyboardAvoidingView, TextInput, TouchableWithoutFeedback } from 'react-native';
import { ImageBackground, Text, TouchableOpacity, View } from 'react-native';
import imagesPath from '../utils/imagesPath';
import { allRex, AllThemeColors, AllThemeFonts, ms } from '../utils/responsive';
const interval = {}
const Home = ({ navigation }) => {
    const flatListRef = React.useRef()
    const [newTime, setNewTime] = useState('')
    const [addRow, setAddRow] = useState('')
    const [timerList, setTimerList] = useState([])
    // { time: 100, status: 'Start' }
    const setTime = (text, index) => {
        let arr = [...timerList]
        arr[index].status = 'Start'
        clearInterval(interval[arr[index].timerCounter])
        arr[index].time = text
        console.log(text, index)
        setTimerList(arr)



    }
    const changeStatus = (item, index) => {
        Keyboard.dismiss()
        let arr = [...timerList]
        if ((item.status == 'Start' || item.status == 'Resume') && item.time > 0) {
            arr[index].status = 'Pause'
            startTimer(item, index)
        } else if (item.status == 'Pause') {
            arr[index].status = 'Resume'
            clearInterval(interval[item.timerCounter])
        }
        setTimerList(arr)
    }
    const startTimer = (item, index) => {
        let arr = [...timerList]
        if (!item.timerCounter) {
            arr[index].timerCounter = 'counter_' + index
        } else {
            clearInterval(interval[item.timerCounter])
        }
        if (item.time) {
            startTimeCount(item, index)
        }
    }
    const startTimeCount = (item, index) => {

        interval[item.timerCounter] = setInterval(() => {
            let arr = [...timerList]
            let time = arr[index].time
            if (time > 0) {
                time = time - 1
            } else {
                time = 0
                arr[index].status = 'Start'
                clearInterval(interval[item.timerCounter])
            }
            arr[index].time = time
            console.log(arr)
            setTimerList(arr)
        }, 1000);
    }
    const AddRow = () => {
        if (newTime) {
            Keyboard.dismiss()
            setNewTime('')
            let arr = [...timerList]
            arr.map((item) => {
                if (item.timerCounter) {
                    clearInterval(interval[item.timerCounter])
                }
            })
            arr.push({ time: newTime.toString(), status: 'Start' })
            setTimerList(arr);
            setAddRow(new Date())
            setTimeout(() => {
                flatListRef.current.scrollToEnd()
            }, 200);
        }
    }
    useEffect(() => {
        timerList.map((item, index) => {
            if (item.status == 'Pause') {
                startTimeCount(item, index)
            }
        })
    }, [addRow])
    const timerRow = (item, index, newRow) => {
        return (
            <View style={{ padding: ms(10), margin: ms(10), backgroundColor: AllThemeColors.white, borderRadius: ms(8), flex: newRow ? null : 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
                <TextInput
                    value={newRow ? newTime : item.time + ''}
                    onChangeText={(text) => newRow ? setNewTime(text.replace(allRex.integerRex, '')) : setTime(text.replace(allRex.integerRex, ''), index)}
                    maxLength={100}
                    placeholder={'Enter time'}
                    autoCompleteType='off'
                    autoCorrect={false}
                    underlineColorAndroid={'transparent'}
                    keyboardType='numeric'
                    returnKeyType='done'
                    style={{ flex: 1, padding: ms(10), borderWidth: ms(1), borderColor: AllThemeColors.themeColorPrimary, color: AllThemeColors.black, height: ms(45) }}
                />
                <View style={{ flex: 1.5, paddingHorizontal: ms(10), marginHorizontal: ms(10), borderWidth: ms(1), borderColor: AllThemeColors.themeColorPrimary, height: ms(45), justifyContent: 'center' }}>
                    <Text adjustsFontSizeToFit numberOfLines={1} style={{ color: AllThemeColors.black }}>
                        {newRow ? (newTime ? moment.utc(newTime * 1000).format('HH:mm:ss') : '00:00:00') : (item.time ? moment.utc(item.time * 1000).format('HH:mm:ss') : '00:00:00')}
                    </Text>
                </View>
                <View style={{ flex: 1, paddingVertical: ms(10) }}>
                    {newRow ?
                        <TouchableOpacity onPress={() => AddRow()} style={{ backgroundColor: AllThemeColors.themeColorPrimary, borderRadius: ms(8), alignItems: 'center', justifyContent: 'center' }}>
                            <Text adjustsFontSizeToFit numberOfLines={1} style={{ color: AllThemeColors.white, padding: ms(10) }}>
                                Add Timer
                            </Text>
                        </TouchableOpacity>
                        :
                        <TouchableOpacity onPress={() => changeStatus(item, index)} style={{ backgroundColor: item.status == 'Start' ? AllThemeColors.creditColor : item.status == 'Pause' ? AllThemeColors.debitColor : AllThemeColors.themeColorPrimary, borderRadius: ms(8), alignItems: 'center', justifyContent: 'center' }}>
                            <Text adjustsFontSizeToFit numberOfLines={1} style={{ color: AllThemeColors.white, padding: ms(10) }}>
                                {item.status}
                            </Text>
                        </TouchableOpacity>}
                </View>
            </View>
        )
    }

    return (
        <KeyboardAvoidingView style={{ flex: 1 }} keyboardVerticalOffset={ms(100)} enabled>
            <ImageBackground
                source={imagesPath.Common.background}
                style={{ height: '100%', width: '100%' }}
            >
                {timerRow('', '', true)}
                <View>
                    <FlatList
                        ref={flatListRef}
                        data={timerList}
                        inverted
                        renderItem={({ item, index }) => timerRow(item, index)}
                        extraData={timerList}
                        showsVerticalScrollIndicator={false}
                        keyExtractor={(item, index) => index}
                    />
                </View>
            </ImageBackground>
        </KeyboardAvoidingView>

    )
}

export default Home;
