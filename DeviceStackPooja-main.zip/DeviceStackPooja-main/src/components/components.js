import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { AllThemeColors, AllThemeFonts, fontFamily, ms, mvs } from "../utils/responsive";
const styles = StyleSheet.create({
    spinnerContainer: { height: '100%', width: '100%', backgroundColor: '#ffffff', alignItems: 'center', justifyContent: 'center', position: 'absolute', zIndex: 9999 },

})
export const CommonSpinner = ({
    loaderText = ''
}) => (
    <View style={styles.spinnerContainer}>
        <View style={{ alignItems: 'center', justifyContent: 'center' }}>
            <ActivityIndicator style={{ transform: [{ scale: mvs(1) }] }} size='large' color={AllThemeColors.themeColorPrimary}
            />
        </View>

        {loaderText ?
            <Text style={{ fontSize: ms(AllThemeFonts.mediumText), textAlign: 'center', color: AllThemeColors.themeColorPrimary, marginTop: ms(20), }}>{loaderText}</Text>
            : null}
    </View>
)